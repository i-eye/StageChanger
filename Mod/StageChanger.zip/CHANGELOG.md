
#Changelog

## 0.3.2
- Every thing should be working as intended
- Night stages show up
- Setting Shattered Abdodes to stage 1 doesn't break everything
- Config made (hopefully) a little less confusing

## 0.3.1
- Made Verdant Falls stage changing actually work

## 0.3.0
- Added support to make night variations of stages into an alternate version instead of a looped version

## 0.2.1
- Updated typo in description


## 0.2.0
- Changed default Shattered Abodes stage to stage 2
- Added support for adding Reformed Altar and Treeborn Colony to the regular path

## 0.1.0
Initial Release