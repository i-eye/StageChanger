# Description

This mod aims to fix some (personal) issues with the ordering of new stages. Featuring a small config!

This mod is not finished, ping IEye on the modding server for feature requests.

Currently featuring:
- Change to the Path of the Colossus works: Now you will start on Reformed Altar from a regular green portal regardles of what stage you started on. And after a Gilded Coast green portal you will end up on Treeborn Colony.(Able to be turned off in config)
- A configurable way to change which stage Shattered Abodes/Distrubed Impact. By default 3.

