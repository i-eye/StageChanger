# Description

This mod aims to fix some (personal) issues with the ordering of new stages. Featuring a small config!

This mod is not finished, ping IEye on the modding server for feature requests.

Currently featuring:
- Change to the Path of the Colossus works: Now you will start on Reformed Altar from a regular green portal regardles of what stage you started on. And after a Gilded Coast green portal you will end up on Treeborn Colony.(Able to be turned off in config)
- A configurable way to change which stage Shattered Abodes/Distrubed Impact. By default 2.
- A configurable way to add Reformed Altar and Treeborn Colony to the regular stage pool(by default stage 2 and 3 respectively)
- A config option to make night variations alternate versions of stages instead of looped versions

# Bugs
This is an unfinished mod, there are bound to be bugs. Ping IEye on the modding server and I will try to fix them.

